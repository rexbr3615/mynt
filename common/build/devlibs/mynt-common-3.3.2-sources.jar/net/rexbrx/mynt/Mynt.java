package net.rexbrx.mynt;

import net.rexbrx.mynt.utils.myLogger;

public final class Mynt {
    public static final String MODID = "mynt";

    public static void init() {
        myLogger.myDebug("|-----------------------------|");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("| Hello World, from Mynt4! ;) |");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("| v3.3.2 | release |  RexBRX  |");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("|-----------------------------|");
    }
}
