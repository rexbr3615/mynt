package net.rexbrx.mynt.global.server.items;

import net.minecraft.world.item.Item;

public class MyntItemMMC extends Item {
    public float mmr = 0;

    public MyntItemMMC(Properties properties, Float mmc) {
        super(properties);
        mmc = mmr;
    }
}
