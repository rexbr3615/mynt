package net.rexbrx.mynt;

import net.rexbrx.mynt.init.core;
import net.rexbrx.mynt.utils.myLogger;

public final class Mynt {
    public static final String MODID = "mynt";

    public static void init() {
        core.init();
    }
}
