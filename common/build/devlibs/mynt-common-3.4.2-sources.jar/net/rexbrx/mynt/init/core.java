package net.rexbrx.mynt.init;

import net.rexbrx.mynt.utils.myLogger;

public class core {
    public static void init() {
        myLogger.myDebug("|-----------------------------|");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("| Hello World, from Mynt4! ;) |");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("| v3.4.0 | release |  RexBRX  |");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("|-----------------------------|");
    }
}
