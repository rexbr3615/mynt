package net.rexbrx.mynt.wine;

public class myClockCalculator
{
    public static float Minutes(Float minutes) {
        return 20 * (60 * minutes);
    }

    public static float Hours(Float hours) {
        return 20 * (60 * (hours * 60));
    }
}
