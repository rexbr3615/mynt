package net.rexbrx.mynt.global.server.blocks;

import net.minecraft.class_2248;
import net.minecraft.class_2498;

public class MyntStoneOreBlock extends class_2248 {
    public MyntStoneOreBlock(class_2251 properties) {
        super(properties.method_9632(3f).method_36558(3f).method_29292().method_9626(class_2498.field_11544));
    }
}
