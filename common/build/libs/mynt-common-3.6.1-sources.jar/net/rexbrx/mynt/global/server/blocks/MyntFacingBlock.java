package net.rexbrx.mynt.global.server.blocks;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3612;
import net.minecraft.world.level.block.*;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public class MyntFacingBlock extends class_2248 {
    public static final class_2753 FACING = class_2383.field_11177;

    public MyntFacingBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        boolean flag = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    public class_2680 method_9598(class_2680 state, class_2470 rot) {
        return state.method_11657(FACING, rot.method_10503(state.method_11654(FACING)));
    }

    public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
        return state.method_26186(mirrorIn.method_10345(state.method_11654(FACING)));
    }
}