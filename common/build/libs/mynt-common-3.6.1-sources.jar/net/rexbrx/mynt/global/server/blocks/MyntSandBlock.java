package net.rexbrx.mynt.global.server.blocks;

import net.minecraft.class_2248;
import net.minecraft.class_2498;

public class MyntSandBlock extends class_2248 {
    public MyntSandBlock(class_2251 properties) {
        super(properties.method_9632(0.5f).method_36558(0.5f).method_9626(class_2498.field_11526));
    }

}
