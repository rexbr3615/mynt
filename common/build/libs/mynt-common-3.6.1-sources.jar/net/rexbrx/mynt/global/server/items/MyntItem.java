package net.rexbrx.mynt.global.server.items;

import net.minecraft.class_1792;

public class MyntItem extends class_1792 {
    public MyntItem(class_1793 properties) {
        super(properties);
    }
}
