package net.rexbrx.mynt.global.server.blocks;

import net.minecraft.class_2248;
import net.minecraft.class_2498;

public class MyntDeepslateOreBlock extends class_2248 {
    public MyntDeepslateOreBlock(class_2251 properties) {
        super(properties.method_9632(3.5f).method_36558(4.5f).method_29292().method_9626(class_2498.field_29033));
    }
}
