package net.rexbrx.mynt.global.server.blocks;

import net.minecraft.class_2248;

public class MyntBlock extends class_2248 {
    public MyntBlock(class_2251 properties) {
        super(properties);
    }
}
