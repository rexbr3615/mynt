package net.rexbrx.mynt.global.server.items;

import net.minecraft.class_1792;

public class MyntItemMMC extends class_1792 {
    public float mmr = 0;

    public MyntItemMMC(class_1793 properties, Float mmc) {
        super(properties);
        mmc = mmr;
    }
}
