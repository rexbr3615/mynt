package net.rexbrx.mynt.init;

import net.rexbrx.mynt.utils.myLogger;

public class MyntCore {
    public static void init() {
        myLogger.myDebug("|-----------------------------|");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("| Hello World, from Mynt4! ;) |");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("| v3.5.1 | release |  RexBRX  |");
        myLogger.myDebug("|                             |");
        myLogger.myDebug("|-----------------------------|");
    }
}
