package net.rexbrx.mynt.utils;

public enum myLoggerLevels {

}
