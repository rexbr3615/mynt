package net.rexbrx.mynt.utils;

import net.rexbrx.mynt.Mynt;

import java.util.logging.Level;
import java.util.logging.Logger;

public class myComplexLogger
{
    public static Logger internal_log = Logger.getLogger(Mynt.MODID);

    public static void myPrint (String Input) {
        internal_log.setLevel(Level.FINE);
        internal_log.fine(Input);
    }

    public static void myDebug (String Input) {
        internal_log.setLevel(Level.CONFIG);
        internal_log.config(Input);
    }

    public static void myInfo (String Input) {
        internal_log.setLevel(Level.INFO);
        internal_log.info(Input);
    }

    public static void myWarn (String Input) {
        internal_log.setLevel(Level.WARNING);
        internal_log.warning(Input);
    }

    public static void myError (String Input) {
        internal_log.setLevel(Level.SEVERE);
        internal_log.severe(Input);
    }

}
