package net.rexbrx.mynt.wine;

public enum AnimalSizeClass {
    ANY("any"),
    ANT("ant"),
    MINUSCULE("minuscule"),
    TINY("tiny"),
    SMALL("small"),
    COMPACT("compact"),
    MEDIUM("medium"),
    BIG("big"),
    LARGE("large"),
    HUGE("huge"),
    GIANT("giant"),
    TITANIC("titanic"),
    BEHEMOTH("behomoth");

    private final String name;

    public String getName() {
        return this.name;
    }

    AnimalSizeClass(String name) {
        this.name = name;
    }

    public boolean isLargerThan(AnimalSizeClass other) {
        return (ordinal() > other.ordinal());
    }

    public boolean isSmallerThan(AnimalSizeClass other) {
        return (ordinal() < other.ordinal());
    }
}

