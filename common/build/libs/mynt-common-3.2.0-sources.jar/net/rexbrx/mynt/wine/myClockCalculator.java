package net.rexbrx.mynt.wine;

public class myClockCalculator
{
    public static float Minutes(Float minutes) {
        return 20 * (60 * minutes);
    }
    public static float Minutes(int minutes) {
        return 20 * (60 * minutes);
    }

    public static float Hours(Float hours) {
        return 20 * (60 * (hours * 60));
    }
    public static float Hours(int hours) {
        return 20 * (60 * (hours * 60));
    }

    public static float CalcSizeByTimeInMinutes(float initSize, float finalSize, float time) {
        return (initSize - finalSize) * Minutes(time);
    }
    public static float CalcSizeByTimeInMinutes(float initSize, float finalSize, int time) {
        return (initSize - finalSize) * Minutes(time);
    }
}
