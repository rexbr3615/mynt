package net.rexbrx.mynt.oasis;

import net.minecraft.class_332;

public class myInterfaceUtils
{
    public static void drawHorizontalLine(class_332 guiGraphics, int startX, int endX, int y, int color) {
        if (endX < startX) {
            int i = startX;
            startX = endX;
            endX = i;
        }
        guiGraphics.method_25294(startX, y, endX + 1, y + 1, color);
    }

    public static void drawVerticalLine(class_332 guiGraphics, int x, int startY, int endY, int color) {
        if (endY < startY) {
            int i = startY;
            startY = endY;
            endY = i;
        }
        guiGraphics.method_25294(x, startY + 1, x + 1, endY, color);
    }
}
