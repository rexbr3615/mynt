package net.rexbrx.mynt.oasis;

import net.minecraft.class_2960;
import net.rexbrx.mynt.Mynt;

public class myIdentifiers {

    public static class_2960 fromNamespaceAndPath(String namespace, String location) {
        return class_2960.method_60655(namespace, location);
    }

    public static class_2960 fromVanillaNamespaceAndPath(String location) {
        return class_2960.method_60655("minecraft", location);
    }

    public static class_2960 fromParse(String location) {
        return class_2960.method_60654(location);
    }
}
