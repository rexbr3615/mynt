package net.rexbrx.mynt;

public final class Mynt {
    public static final String MODID = "mynt";

    public static void init() {
        // Write common init code here.
    }
}
